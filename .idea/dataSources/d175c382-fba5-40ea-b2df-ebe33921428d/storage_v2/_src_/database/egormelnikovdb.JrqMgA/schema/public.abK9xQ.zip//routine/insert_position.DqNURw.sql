create function insert_position() returns trigger
    language plpgsql
as
$$
DECLARE
    notification json;
    channel      text := TG_ARGV[0];
BEGIN
--     SELECT row_to_json(row) into notification from (select * from positions ORDER BY id_ DESC LIMIT 1) row;
--     PERFORM pg_notify('events', notification::text);
--     RETURN NULL;
        PERFORM (
        with pos(id_, price_open, is_bay, symbol, price_close, bay_by) as
                 (
                     select new.id_, new.price_open, new.is_bay, new.symbol, new.price_close, new.bay_by
                 )
        select pg_notify(channel, row_to_json(pos)::text)
        from pos
    );
    Return NULL;
END;

$$;

alter function insert_position() owner to egormelnikov;

