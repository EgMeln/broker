create function insert_position() returns trigger
    language plpgsql
as
$$
DECLARE
    channel text := TG_ARGV[0];
BEGIN
        PERFORM (
        with pos(id_, price_open, is_bay, symbol, price_close, bay_by, user_id, stop_loss, take_profit) as
                 (
                     select new.id_,
                            new.price_open,
                            new.is_bay,
                            new.symbol,
                            new.price_close,
                            new.bay_by,
                            new.user_id,
                            new.stop_loss,
                            new.take_profit
                 )
        select pg_notify(channel, row_to_json(pos)::text)
        from pos
    );
    Return NULL;
END;

$$;

alter function insert_position() owner to egormelnikov;

